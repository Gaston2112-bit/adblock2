package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var debug: TextView
    private lateinit var button: Button

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                AdBlockVpnService.lastMsg = "Permiso concedido, iniciando servicio..."
                try {
                    startService(Intent(this, AdBlockVpnService::class.java))
                } catch (e: Exception) {
                    AdBlockVpnService.lastMsg = "Error al iniciar: ${e.javaClass.simpleName}: ${e.message}"
                }
            } else {
                AdBlockVpnService.lastMsg =
                    "El sistema no dio permiso de VPN (código ${result.resultCode})"
            }
            refresh()
            refreshLater()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
        }
        button = Button(this)
        button.setOnClickListener { toggle() }
        debug = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 0)
        }

        layout.addView(status)
        layout.addView(button)
        layout.addView(debug)
        setContentView(layout)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toggle() {
        try {
            if (AdBlockVpnService.running) {
                val stop = Intent(this, AdBlockVpnService::class.java)
                stop.action = AdBlockVpnService.ACTION_STOP
                startService(stop)
            } else {
                AdBlockVpnService.lastMsg = "Botón tocado, pidiendo permiso de VPN..."
                refresh()
                val intent = VpnService.prepare(this)
                if (intent != null) {
                    vpnPermission.launch(intent)
                } else {
                    AdBlockVpnService.lastMsg = "Permiso ya concedido, iniciando servicio..."
                    startService(Intent(this, AdBlockVpnService::class.java))
                }
            }
        } catch (e: Exception) {
            AdBlockVpnService.lastMsg = "Error: ${e.javaClass.simpleName}: ${e.message}"
        }
        refresh()
        refreshLater()
    }

    private fun refreshLater() {
        button.postDelayed({ refresh() }, 600)
        button.postDelayed({ refresh() }, 2000)
    }

    private fun refresh() {
        if (AdBlockVpnService.running) {
            status.text = "Bloqueo de anuncios ACTIVADO"
            button.text = "Desactivar"
        } else {
            status.text = "Bloqueo de anuncios DESACTIVADO"
            button.text = "Activar"
        }
        debug.text = "Estado: " + AdBlockVpnService.lastMsg
    }
}
